/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tigadimensi;

/**
 *
 * @author ROG
 */
public class Balok extends PersegiPanjang implements Ruang{

    double Tinggi;

    public Balok(double Panjang, double Lebar, double Tinggi) 
    {
        this.setPanjang(Panjang);
        this.setLebar(Lebar);
        this.Tinggi = Tinggi;
    }
    
    @Override
    public double Volume() 
    {
        return Volume(this.getPanjang(),this.getLebar(),this.Tinggi);
    }
    
    public double Volume(double Panjang, double Lebar, double Tinggi)
    {
        return Panjang * Lebar * Tinggi;
    }

    @Override
    public double LPermukaan() 
    {
        return LPermukaan(this.getPanjang(), this.getLebar(), this.Tinggi);
    }
    
    public double LPermukaan(double Panjang, double Lebar, double Tinggi)
    {
        return 2 * ((Panjang * Lebar)+(Panjang * Tinggi)+(Lebar * Tinggi));
    }

}
        
