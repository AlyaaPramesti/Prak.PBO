/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tigadimensi;

/**
 *
 * @author ROG
 */
public class Tabung extends Lingkaran implements Ruang {
    
    double Tinggi;
    double phi;

    public Tabung(double JariJari, double Tinggi) 
    {
        this.setJariJari(JariJari);
        this.Tinggi = Tinggi;
    }

    Tabung(Double jarijari, Double tinggi) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    

    @Override
    public double Volume() 
    {
        return Volume(this.Luas(),this.Tinggi);
    }
    
    public double Volume(double Luas, double Tinggi)
    {
        return Luas * Tinggi;
    }

    @Override
    public double LPermukaan() 
    {
        return LPermukaan(this.Luas(), this.Keliling() , this.Tinggi);
    }
    
    public double LPermukaan(double Luas, double Keliling, double Tinggi)
    {  
        return (2 * Luas)+(Keliling * Tinggi);  
    }  
}