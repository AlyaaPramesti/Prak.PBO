/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tigadimensi;

/**
 *
 * @author ROG
 */
public class Lingkaran implements Bidang {
    double phi = 3.14;
    double JariJari;

    public double getJariJari() 
    {
        return JariJari;
    }

    public void setJariJari(double JariJari) 
    {
        this.JariJari = JariJari;
    }

    @Override
    public double Keliling() 
    {
        return Keliling(this.JariJari);
    }
    
    public double Keliling(double JariJari)
    {
        return 2 * phi * JariJari;
    }

    @Override
    public double Luas() 
    {
        return Luas(this.JariJari);
    }
    
    public double Luas(double JariJari)
    {
        return phi * JariJari * JariJari;
    }   
}
