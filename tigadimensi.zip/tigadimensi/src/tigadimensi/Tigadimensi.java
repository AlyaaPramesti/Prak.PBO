/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tigadimensi;

import java.util.Scanner;

/**
 *
 * @author ROG
 */
public class Tigadimensi {
    static int pilihan;
    
    public static void main(String[] args) {
       Scanner input = new Scanner(System.in);
       double panjang, lebar, tinggi, jarijari;
       double Luas, Volume;
       int pengulangan = 1;
       
     do{  
       System.out.println("==========");
       System.out.println("Menu Utama");
       System.out.println("==========");
       System.out.println("1. Hitung Balok");
       System.out.println("2. Hitung Tabung");
       System.out.println("0. Exit");
       System.out.print("Pilih = ");
       pilihan = input.nextInt();
       
       switch (pilihan){
           case 1 :
                System.out.print("Input Panjang : ");
                panjang = input.nextDouble();
 
                System.out.print("Input Lebar   : ");
                lebar = input.nextDouble();
 
                System.out.print("Input Tinggi  : ");
                tinggi = input.nextDouble();
                
                Balok B = new Balok(panjang, lebar, tinggi);
                
                System.out.println("Luas Persegi Panjang   :" + B.Luas());
                
                System.out.println("Keliling Persegi Panjang   :" + B.Keliling());
 
                System.out.println("Volume Balok : " + B.Volume());
                
                System.out.println("Luas Permukaan Balok   :" + B.LPermukaan());
                
                System.out.println("ulangi? (Ya : 1 || Tidak : 0) : ");
                pengulangan = input.nextInt();
                break;
                
           case 2 :
                System.out.print("Input Tinggi  : ");
                tinggi = input.nextDouble();
                
                System.out.print("Input Jari-Jari  : ");
                jarijari = input.nextDouble();
                
                Tabung T = new Tabung (jarijari, tinggi);
                
                System.out.println("Luas Lingkran : " + T.Luas());

                System.out.println("Keliling Lingkaran   : " + T.Keliling());
            
                System.out.println("Volume Tabung : " + T.Volume());
                
                System.out.println("Luas Permukaan Tabung : " + T.LPermukaan());
                
                System.out.println("ulangi? (Ya : 1 || Tidak : 0) : "); 
                pengulangan = input.nextInt();
                break;
           case 0:
             System.out.println("Anda telah keluar");
             System.exit(0);
            }
    
         }while(pengulangan==1);
    }
}
        
