/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tigadimensi;

/**
 *
 * @author ROG
 */
public class PersegiPanjang implements Bidang {
    private double Panjang, Lebar;

    public double getPanjang() 
    {
        return Panjang;
    }

    public void setPanjang(double Panjang) 
    {
        this.Panjang = Panjang;
    }

    public double getLebar() 
    {
        return Lebar;
    }

    public void setLebar(double Lebar) 
    {
        this.Lebar = Lebar;
    }

    @Override
    public double Keliling() 
    {
        return Keliling(this.Panjang, this.Lebar);
    }
    
    public double Keliling(double Panjang, double Lebar)
    {
        return 2 * (Panjang + Lebar);
    }

    @Override
    public double Luas() 
    {
        return Luas(this.Panjang, this.Lebar);
    }
    
    public double Luas(double Panjang, double Lebar)
    {
        return Panjang * Lebar;
    }  
}